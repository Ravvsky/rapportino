import { redirect } from "next/navigation";

export default function SettingsPage() {
  return <div>aaa</div>
  redirect("/settings/personal");
}