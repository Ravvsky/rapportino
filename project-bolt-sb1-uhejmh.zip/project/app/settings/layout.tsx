import { Cog } from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";

const sidebarNavItems = [
  {
    title: "Personal",
    href: "/settings/personal",
    icon: "user",
  },
  {
    title: "Account",
    href: "/settings/account",
    icon: "settings",
  },
  {
    title: "Notifications",
    href: "/settings/notifications",
    icon: "bell",
  },
];

interface SettingsLayoutProps {
  children: React.ReactNode;
}

export default function SettingsLayout({ children }: SettingsLayoutProps) {
  return (
    <div className="container relative mx-auto flex min-h-screen max-w-7xl flex-col space-y-6 py-8">
      <div className="flex items-center space-x-2">
        <Cog className="h-6 w-6" />
        <h1 className="text-2xl font-bold">Settings</h1>
      </div>
      <div className="flex flex-col space-y-8 lg:flex-row lg:space-x-12 lg:space-y-0">
        <aside className="lg:w-1/5">
          <nav className="flex space-x-2 lg:flex-col lg:space-x-0 lg:space-y-1">
            {sidebarNavItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  buttonVariants({ variant: "ghost" }),
                  "justify-start"
                )}
              >
                {item.title}
              </Link>
            ))}
          </nav>
        </aside>
        <div className="flex-1">{children}</div>
      </div>
    </div>
  );
}